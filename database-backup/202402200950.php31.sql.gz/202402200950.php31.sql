-- MariaDB dump 10.19  Distrib 10.11.5-MariaDB, for Linux (x86_64)
--
-- Host: mysql    Database: php31
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `credentials`
--

DROP TABLE IF EXISTS `credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credentials` (
  `name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `domain` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `cms-username` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `cms-password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credentials`
--

LOCK TABLES `credentials` WRITE;
/*!40000 ALTER TABLE `credentials` DISABLE KEYS */;
INSERT INTO `credentials` VALUES
('name','domain','cms-username','cms-password'),
('Browsecat','hc360.com','pdeetlefs0','mPaf0XcoXO'),
('Dabtype','vinaora.com','hbartelsellis1','ROfJxYo6IZDF'),
('Realbuzz','theatlantic.com','ajosey2','ei80rdj6V'),
('Digitube','yellowbook.com','chacquoil3','tfBrU42rWwNC'),
('Dabfeed','plala.or.jp','gdallewater4','8BkSvaYGvIo'),
('Dabfeed','themeforest.net','kingledow5','yKRLHcRuMJ9'),
('Edgetag','liveinternet.ru','mdefreyne6','YAd7GIwNK1'),
('Chatterbridge','nsw.gov.au','kwandless7','Zqp7R36'),
('Twimbo','sina.com.cn','cavrahamoff8','vkqolxSlxteG'),
('Yacero','ycombinator.com','ctuffell9','G9tfnvsTv4'),
('Rhynoodle','spotify.com','ymccartneya','eLrgp50TLO6r'),
('Skinder','weibo.com','hbaskwellb','SwNkqgVJ'),
('Zoomcast','indiatimes.com','paddionisioc','bY584Z3lgkSy'),
('Agivu','shareasale.com','jrosed','GvEdUbbA6'),
('Jabberbean','miibeian.gov.cn','fpeddowee','PrT4xiN'),
('Chatterpoint','etsy.com','scornishf','sZUq8jNmt4s'),
('Jetwire','cbslocal.com','lhughg','S2A9SrYva'),
('Realfire','barnesandnoble.com','cflecknoh','gi1ZYSOKXvxf'),
('Muxo','amazon.de','dmalenoiri','uTojwCXyh'),
('Wordify','jalbum.net','aelwelj','uSp43cnBt2E'),
('Topicstorm','noaa.gov','gcappellk','v4OCVfnk0'),
('Flashset','ted.com','awaskettl','hAiumUpA'),
('Dazzlesphere','columbia.edu','mroskeillym','XcFxoD65GXT'),
('Riffpath','godaddy.com','dfinchamn','WL5a7y'),
('Bubbletube','oakley.com','tstandingo','fZriVHPTyJkH'),
('Quatz','eventbrite.com','eburstowep','sIJqnF'),
('Camimbo','ed.gov','gladdleq','6dliuMc'),
('Trupe','businesswire.com','smackellenr','3uPB1YCEp'),
('Agivu','opera.com','mguittes','oXPreXz'),
('Dynava','msu.edu','hsantorat','SaBAhZLMM2'),
('Katz','istockphoto.com','gseadonu','qEj8wyz0GYt'),
('LiveZ','phoca.cz','cmaynellv','GAUhGA9D9'),
('Skipfire','constantcontact.com','adunphyw','hUM1oxyxN4'),
('Oyoyo','hubpages.com','kcorbittx','PvBFzWmc16'),
('Eayo','ycombinator.com','dreinhardty','4rgMUxsWnlU'),
('Skivee','chronoengine.com','bmazzilliz','IzcQDQgk'),
('Quimm','netvibes.com','bbetonia10','amp7oW'),
('Centimia','gmpg.org','ehansbury11','PSZe2BkZi'),
('Devshare','networkadvertising.org','btrew12','6kI5gc'),
('Shufflester','acquirethisname.com','ttrusse13','PI6VQiAp8'),
('Feedspan','independent.co.uk','jizod14','EzFA9S'),
('Mynte','hud.gov','lveazey15','nnhBpYVyOdDN'),
('Yambee','nydailynews.com','cdominka16','JXDnhAZBG'),
('Nlounge','ft.com','fmoules17','Q00G4Ap9vd'),
('Edgeclub','angelfire.com','mmacalister18','MmOG9GaqyF'),
('Jabbertype','wsj.com','bkelsall19','q3XZE0QMq'),
('Yacero','theglobeandmail.com','egravells1a','1ngMYecJS2MP'),
('Skyble','craigslist.org','vhughson1b','EeBUCfoK0O'),
('Yata','nymag.com','mkerin1c','ryExzwv'),
('Skajo','irs.gov','aleebeter1d','FZIkHCDR');
/*!40000 ALTER TABLE `credentials` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-20  9:50:00
